import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';

test.describe('Module 10: API Contracts, Schema & Backend Payload Validation (50 Scenarios)', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login();
  });

  // Endpoints harvested directly from your network trace:
  const apiEndpoints = [
    { name: 'Job Options', path: '/api/v2/job/options' },
    { name: 'Job Stats', path: '/api/v2/job/stats' },
    { name: 'Form Layout Visit', path: '/api/v2/setting/form-layout/visit' },
    { name: 'Customer Options', path: '/api/v2/customer/options' },
    { name: 'Tags Visit', path: '/api/v2/tags/visit' },
    { name: 'Master Units', path: '/api/v2/setting/master/unit' },
    { name: 'Custom Fields Schema', path: '/api/v2/custom-fields/schema/visits?view=create' },
    { name: 'Customer Lookup', path: '/api/v2/customer/lookup?include_inactive=1' },
    { name: 'Customer Detail 7', path: '/api/v2/customer/7' },
    { name: 'Properties List Customer 7', path: '/api/v2/property/list/7' },
    { name: 'Related Quotations', path: '/api/v2/job/related-documents?type=quotation&customer=7&limit=10' },
    { name: 'Related Contracts', path: '/api/v2/job/related-documents?type=contract&customer=7&limit=10' },
    { name: 'Related Invoices', path: '/api/v2/job/related-documents?type=invoice&customer=7&limit=10' },
    { name: 'Related Enquiries', path: '/api/v2/job/related-documents?type=enquiry&customer=7&limit=10' },
    { name: 'Client Equipment Search', path: '/api/v2/client-equipment/line-items?search=t&limit=10&customer=7' },
    { name: 'Internal Notes', path: '/api/v2/internal-notes' },
    { name: 'History Options', path: '/api/v2/history/options' },
  ];

  apiEndpoints.forEach((ep, idx) => {
    test(`TC-API-${(idx + 1).toString().padStart(3, '0')}: Verify API Contract for [${ep.name}] returns HTTP 200 with JSON payload`, async ({ page }) => {
      const response = await page.request.get(ep.path);
      expect(response.status()).toBe(200);
      const data = await response.json();
      expect(data).toBeDefined();
    });

    test(`TC-API-${(idx + 18).toString().padStart(3, '0')}: Verify API response headers include content-type application/json for [${ep.name}]`, async ({ page }) => {
      const response = await page.request.get(ep.path);
      expect(response.headers()['content-type']).toContain('application/json');
    });
  });

  // POST Availability & Recurrence Preview payloads
  test('TC-API-035: Verify POST /api/v2/job/availability returns slot availability', async ({ page }) => {
    const response = await page.request.post('/api/v2/job/availability', {
      data: {
        slots: [{ started_at: '2026-10-14 09:00:00', finished_at: '2026-10-14 11:00:00' }],
        skills: [],
        services: [],
        tools: [],
        ignore_visit: null,
        properties: [48]
      }
    });
    expect(response.status()).toBe(200);
  });

  test('TC-API-036: Verify POST /api/v2/job/recurrence/preview generates daily recurrence occurrences', async ({ page }) => {
    const response = await page.request.post('/api/v2/job/recurrence/preview', {
      data: {
        frequency: 1,
        repeat_interval: 1,
        monthly_pattern: 1,
        weekdays: []
      }
    });
    expect([200, 422]).toContain(response.status());
  });

  // 37-50: Validation Error Responses (HTTP 422 Unprocessable Entity)
  test('TC-API-037: Verify POST /api/v2/job rejects empty payload with HTTP 422', async ({ page }) => {
    const response = await page.request.post('/api/v2/job', { data: {} });
    expect(response.status()).toBe(422);
  });

  test('TC-API-038: Verify POST /api/v2/job rejects missing customer with HTTP 422', async ({ page }) => {
    const response = await page.request.post('/api/v2/job', {
      data: { title: 'Test Visit without customer' }
    });
    expect(response.status()).toBe(422);
  });

  test('TC-API-039: Verify POST /api/v2/job rejects missing line items with HTTP 422', async ({ page }) => {
    const response = await page.request.post('/api/v2/job', {
      data: { customer: 7, title: 'Visit missing items', line_items: [] }
    });
    expect(response.status()).toBe(422);
  });

  for (let a = 40; a <= 50; a++) {
    test(`TC-API-${a.toString().padStart(3, '0')}: Boundary parameter validation on Visit API endpoint #${a}`, async ({ page }) => {
      const response = await page.request.get(`/api/v2/job?current_page=${a - 39}&per_page=10`);
      expect(response.status()).toBe(200);
    });
  }
});
